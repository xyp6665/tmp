# Data Cleaning Rules

## Required fields

Every record must contain:
- `name`: non-empty string
- `age`: non-negative whole number or numeric string representing one
- `score`: finite number or numeric string from 0 to 100, inclusive

Unknown extra fields are preserved.

## Type normalization

- Trim whitespace around names.
- Convert age to an integer.
- Convert score to a number. Integral scores are represented as integers; decimal scores are rounded to 2 decimal places.
- Reject booleans, empty strings, nulls, NaN, and infinity in numeric fields.
- Do not infer missing values.

## Sorting

- `cleaned_records` retains input order.
- `ranking` sorts score descending.
- Tied scores retain their original relative order (stable sorting).

## Classification

- `优秀`: score >= 90
- `良好`: 80 <= score < 90
- `及格`: 60 <= score < 80
- `不及格`: score < 60

## Statistics

Calculate record count, arithmetic mean score (rounded to 2 decimals), highest score, lowest score, and counts for all four classifications. Include categories with zero records.

## Data integrity

Never discard or invent records. Do not alter unknown fields. The script validates structure and performs arithmetic; it does not verify whether ages or scores are factually correct.
