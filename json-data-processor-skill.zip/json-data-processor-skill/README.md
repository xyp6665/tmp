# JSON Data Processor Skill (Agno)

A minimal Agno Skill designed specifically to test the native `get_skill_script(execute=True)` flow.

## Structure

```text
json-data-processor/
├── SKILL.md
├── references/
│   └── data_cleaning_rules.md
├── scripts/
│   └── process_records.py
├── examples/
│   └── test_prompt.md
└── tests/
    └── test_process_records.py
```

## Agno loading example

Place this folder under the directory scanned by `LocalSkills`, for example `project/skills/json-data-processor/`.

```python
from agno.agent import Agent
from agno.skills import Skills, LocalSkills

skills = Skills(loaders=[LocalSkills("skills")])
print(skills.get_skill_names())
print([tool.name for tool in skills.get_tools()])

agent = Agent(
    model=your_model,
    skills=skills,
    debug_mode=True,
)
```

The Agent should use the native Skill access tools provided by the loaded `Skills` instance. No custom `tools/` directory or custom Agent tool is included in this test package.

## Required script call

```python
get_skill_script(
    skill_name="json-data-processor",
    script_path="process_records.py",
    execute=True,
    args=["--input-json", '{"records":[{"name":"Alice","age":"23","score":"88"}]}'],
    timeout=30,
)
```

The script path is relative to the Skill's `scripts/` directory. Do not prefix it with `scripts/`. `execute=True` is essential; otherwise the script is read, not run.

## Local test (not an Agno integration test)

```bash
python -m unittest discover -s tests -v
python scripts/process_records.py --input-json '{"records":[{"name":"Alice","age":"23","score":"88"}]}'
```

## Execution boundary

`get_skill_script(execute=True)` runs the script in the Python environment where the Agno Agent process is running. It does not create a Docker container or an independent sandbox. If the Agent runs inside your Docker executor, the script runs in that container. Docker isolation and resource limits must be configured separately.
