---
name: json-data-processor
description: Process structured JSON records using the bundled Python script. Use when the user asks to clean, normalize, validate, sort, classify, or summarize a JSON array of student records.
---

# JSON Data Processor

## Purpose

Process a JSON array of student records. The bundled Python script performs validation, type conversion, sorting, score classification, and summary statistics.

**The Agent must execute the bundled script through Agno's native `get_skill_script` tool. Do not calculate the requested statistics yourself.**

## Required workflow

1. Read these instructions.
2. Read `references/data_cleaning_rules.md` with Agno's `get_skill_reference` when applying the default student-record rules.
3. Extract the complete records from the user's request. Do not omit, invent, or alter records.
4. Serialize the records into one compact JSON object: `{"records": [...]}`.
5. Call Agno's native `get_skill_script` tool using exactly these settings:
   - `skill_name="json-data-processor"`
   - `script_path="process_records.py"`
   - `execute=True`
   - `args=["--input-json", "<compact JSON string>"]`
   - `timeout=30`
6. Inspect the execution result:
   - If `returncode` is `0`, parse the JSON from `stdout`.
   - If `returncode` is non-zero, or execution fails, report the error. Do not fabricate results.
   - If `stdout` is empty, inspect `stderr` and report that no result was returned.
7. Present the actual script output. Do not recalculate or silently modify computed values.

## Script path and execution requirements

- The script is in this Skill's `scripts/` directory.
- Pass `script_path="process_records.py"`; do not prepend `scripts/`.
- `execute=True` is mandatory. Without it, Agno reads the script source instead of executing it.
- Pass the JSON payload as one argument after `--input-json`.
- The script uses only the Python standard library.
- The executable entry point is `if __name__ == "__main__"` in the script.

## Input schema

```json
{
  "records": [
    {"name": "Alice", "age": "23", "score": "88"}
  ]
}
```

Each record must contain:
- `name`: non-empty string
- `age`: non-negative whole number or numeric string
- `score`: finite number or numeric string from 0 through 100, inclusive

Numeric strings are converted to numbers. `cleaned_records` preserves input order. `ranking` sorts score descending; ties preserve original order.

## Score classification

- score >= 90: `优秀`
- score >= 80 and < 90: `良好`
- score >= 60 and < 80: `及格`
- score < 60: `不及格`

## Error handling

- Empty records, missing fields, invalid numbers, negative ages, and scores outside 0–100 return an error.
- Never silently drop invalid records.
- Never guess missing name, age, or score.
- Do not claim success unless the script execution returned successfully.

## Expected output

Success:

```json
{
  "status": "success",
  "data": {
    "cleaned_records": [],
    "ranking": [],
    "statistics": {
      "record_count": 0,
      "average_score": 0,
      "highest_score": 0,
      "lowest_score": 0,
      "classification_counts": {}
    }
  },
  "error": null
}
```

Failure:

```json
{
  "status": "error",
  "data": null,
  "error": {
    "type": "ValueError",
    "message": "..."
  }
}
```

These are schema examples only. Always use the actual script output.
