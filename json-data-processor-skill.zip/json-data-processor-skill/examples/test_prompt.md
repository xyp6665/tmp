请使用 `json-data-processor` Skill 处理以下学生数据。必须使用 Agno 原生 `get_skill_script` 工具执行脚本，不允许由模型自行计算。

输入数据：

[
  {"name": "Alice", "age": "23", "score": "88"},
  {"name": "Bob", "age": "25", "score": "92"},
  {"name": "Charlie", "age": "22", "score": "76"},
  {"name": "David", "age": "24", "score": "95"},
  {"name": "Emma", "age": "21", "score": "59"}
]

执行要求：
1. 读取 SKILL.md 指令。
2. 使用 get_skill_reference 读取 `data_cleaning_rules.md`。
3. 将数据整理为包含 `records` 数组的 JSON 对象。
4. 调用 get_skill_script，参数为：
   - skill_name="json-data-processor"
   - script_path="process_records.py"
   - execute=True
   - args=["--input-json", "<完整 JSON 字符串>"]
   - timeout=30
5. 检查返回的 returncode、stdout 和 stderr。
6. 只使用脚本 stdout 中的实际结果，不要自行重新计算。
7. 输出清洗后的记录、排名、统计结果和执行状态。
