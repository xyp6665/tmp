import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "process_records.py"

sys.path.insert(0, str(ROOT / "scripts"))
from process_records import process_records


class ProcessRecordsTests(unittest.TestCase):
    def setUp(self):
        self.records = [
            {"name": "Alice", "age": "23", "score": "88"},
            {"name": "Bob", "age": "25", "score": "92"},
            {"name": "Charlie", "age": "22", "score": "76"},
            {"name": "David", "age": "24", "score": "95"},
            {"name": "Emma", "age": "21", "score": "59"},
        ]

    def test_statistics_and_ranking(self):
        data = process_records(self.records)
        self.assertEqual(data["statistics"]["record_count"], 5)
        self.assertEqual(data["statistics"]["average_score"], 82)
        self.assertEqual(data["statistics"]["highest_score"], 95)
        self.assertEqual(data["statistics"]["lowest_score"], 59)
        self.assertEqual(data["ranking"][0]["name"], "David")
        self.assertEqual(data["cleaned_records"][0]["age"], 23)

    def test_classification_counts(self):
        data = process_records(self.records)
        self.assertEqual(data["statistics"]["classification_counts"],
                         {"优秀": 2, "良好": 1, "及格": 1, "不及格": 1})

    def test_stable_sort_for_ties(self):
        rows = [{"name": "First", "age": 20, "score": 90},
                {"name": "Second", "age": 21, "score": 90}]
        data = process_records(rows)
        self.assertEqual([r["name"] for r in data["ranking"]], ["First", "Second"])

    def test_invalid_score(self):
        with self.assertRaises(ValueError):
            process_records([{"name": "A", "age": 20, "score": 101}])

    def test_missing_field(self):
        with self.assertRaises(ValueError):
            process_records([{"name": "A", "age": 20}])

    def test_cli(self):
        payload = {"records": [{"name": "A", "age": "20", "score": "90"}]}
        result = subprocess.run([sys.executable, str(SCRIPT), "--input-json", json.dumps(payload)],
                                capture_output=True, text=True, check=False)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(json.loads(result.stdout)["status"], "success")


if __name__ == "__main__":
    unittest.main()
