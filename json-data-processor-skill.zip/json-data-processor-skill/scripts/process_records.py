#!/usr/bin/env python3
"""Validate, normalize, rank, classify and summarize JSON student records."""
from __future__ import annotations

import argparse
import json
import math
from typing import Any

CLASSIFICATION_KEYS = ("优秀", "良好", "及格", "不及格")


def _number(value: Any, field: str, index: int) -> float:
    if isinstance(value, bool) or value is None:
        raise ValueError(f"records[{index}].{field} must be a valid number.")
    if isinstance(value, str):
        value = value.strip()
        if not value:
            raise ValueError(f"records[{index}].{field} must not be empty.")
        try:
            result = float(value)
        except ValueError as exc:
            raise ValueError(f"records[{index}].{field} must be numeric; received {value!r}.") from exc
    elif isinstance(value, (int, float)):
        result = float(value)
    else:
        raise ValueError(f"records[{index}].{field} must be a number or numeric string.")
    if not math.isfinite(result):
        raise ValueError(f"records[{index}].{field} must be finite.")
    return result


def _display_number(value: float) -> int | float:
    value = round(value, 2)
    return int(value) if value.is_integer() else value


def _classification(score: float) -> str:
    if score >= 90:
        return "优秀"
    if score >= 80:
        return "良好"
    if score >= 60:
        return "及格"
    return "不及格"


def process_records(records: list[dict[str, Any]]) -> dict[str, Any]:
    if not isinstance(records, list) or not records:
        raise ValueError("records must be a non-empty array.")

    cleaned: list[dict[str, Any]] = []
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            raise ValueError(f"records[{index}] must be a JSON object.")
        name = record.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ValueError(f"records[{index}].name must be a non-empty string.")

        age = _number(record.get("age"), "age", index)
        if age < 0 or not age.is_integer():
            raise ValueError(f"records[{index}].age must be a non-negative whole number.")

        score = _number(record.get("score"), "score", index)
        if not 0 <= score <= 100:
            raise ValueError(f"records[{index}].score must be between 0 and 100.")

        row = dict(record)
        row["name"] = name.strip()
        row["age"] = int(age)
        row["score"] = _display_number(score)
        row["classification"] = _classification(score)
        cleaned.append(row)

    # Python sorting is stable: equal scores keep their original order.
    ranking = sorted(cleaned, key=lambda row: float(row["score"]), reverse=True)
    scores = [float(row["score"]) for row in cleaned]
    counts = {key: 0 for key in CLASSIFICATION_KEYS}
    for row in cleaned:
        counts[row["classification"]] += 1

    data = {
        "cleaned_records": cleaned,
        "ranking": ranking,
        "statistics": {
            "record_count": len(cleaned),
            "average_score": _display_number(math.fsum(scores) / len(scores)),
            "highest_score": _display_number(max(scores)),
            "lowest_score": _display_number(min(scores)),
            "classification_counts": counts,
        },
    }
    return data


def main() -> int:
    parser = argparse.ArgumentParser(description="Clean and summarize JSON student records.")
    parser.add_argument("--input-json", required=True, help="JSON object containing a records array")
    args = parser.parse_args()
    try:
        payload = json.loads(args.input_json)
        if not isinstance(payload, dict):
            raise ValueError("Input must be a JSON object containing a 'records' array.")
        data = process_records(payload.get("records"))
        result = {"status": "success", "data": data, "error": None}
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        return 0
    except json.JSONDecodeError as exc:
        result = {"status": "error", "data": None,
                  "error": {"type": "JSONDecodeError", "message": f"Invalid input JSON: {exc.msg}"}}
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        return 2
    except Exception as exc:
        result = {"status": "error", "data": None,
                  "error": {"type": type(exc).__name__, "message": str(exc)}}
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
