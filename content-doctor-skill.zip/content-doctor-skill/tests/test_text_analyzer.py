import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tools"))

from text_analyzer import analyze_text, compare_texts
from text_quality_tools import analyze_content, compare_versions

class ContentDoctorTests(unittest.TestCase):
    def test_sentence_and_paragraph_counts(self):
        result = analyze_text("第一句。第二句！\n\n第三句。")
        self.assertEqual(result["sentence_count"], 3)
        self.assertEqual(result["paragraph_count"], 2)

    def test_duplicate_detection(self):
        result = analyze_text("内容需要优化。内容需要优化。另一个句子。")
        self.assertEqual(result["duplicate_sentence_count"], 1)

    def test_long_sentence_detection(self):
        result = analyze_text("这是一句很长的句子" * 8, long_sentence_threshold=20)
        self.assertGreater(result["long_sentence_count"], 0)

    def test_comparison(self):
        result = compare_texts("这是一段很长的原始文本。", "优化后的文本。")
        self.assertLess(result["change"]["character_count_delta"], 0)

    def test_tool_wrapper(self):
        self.assertEqual(analyze_content("测试文本。")["status"], "success")
        self.assertEqual(analyze_content("   ")["status"], "error")
        self.assertEqual(compare_versions("原文。", "修改稿。")["status"], "success")

if __name__ == "__main__":
    unittest.main(verbosity=2)
