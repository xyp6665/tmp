"""Bottom-level text analysis scripts."""
