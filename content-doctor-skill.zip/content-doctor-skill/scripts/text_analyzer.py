"""Deterministic text metrics for Content Doctor; standard library only."""
import re
from collections import Counter

POTENTIAL_FILLER_PHRASES = [
    "在一定程度上", "值得注意的是", "非常", "比较",
    "相关", "进行", "然后", "其实"
]

def _validate_text(text):
    if not isinstance(text, str):
        raise ValueError("text must be a string.")
    if not text.strip():
        raise ValueError("text must not be empty.")
    return text.strip()

def _sentences(text):
    parts = re.split(r"(?<=[。！？!?])\s*|\n+", text.strip())
    return [p.strip() for p in parts if p.strip()]

def analyze_text(text, long_sentence_threshold=60):
    text = _validate_text(text)
    if isinstance(long_sentence_threshold, bool) or not isinstance(long_sentence_threshold, int) or long_sentence_threshold < 1:
        raise ValueError("long_sentence_threshold must be a positive integer.")
    compact = re.sub(r"\s", "", text)
    paragraphs = [p for p in re.split(r"\n\s*\n", text) if p.strip()]
    sentences = _sentences(text)
    lengths = [len(re.sub(r"\s", "", s)) for s in sentences]
    normalized = [re.sub(r"\s+", "", s).lower() for s in sentences]
    counts = Counter(normalized)
    duplicates = [{"sentence": s, "count": n} for s, n in counts.items() if n > 1]
    fillers = [{"phrase": p, "count": text.count(p)} for p in POTENTIAL_FILLER_PHRASES if text.count(p)]
    return {
        "character_count": len(compact),
        "chinese_character_count": len(re.findall(r"[\u4e00-\u9fff]", text)),
        "english_word_count": len(re.findall(r"\b[A-Za-z]+(?:['’-][A-Za-z]+)?\b", text)),
        "paragraph_count": len(paragraphs),
        "sentence_count": len(sentences),
        "average_sentence_length": round(sum(lengths) / len(lengths), 2) if lengths else 0,
        "longest_sentence_length": max(lengths, default=0),
        "long_sentence_threshold": long_sentence_threshold,
        "long_sentence_count": sum(n > long_sentence_threshold for n in lengths),
        "duplicate_sentence_count": sum(n - 1 for n in counts.values() if n > 1),
        "duplicate_sentences": duplicates,
        "potential_filler_phrases": fillers
    }

def compare_texts(original_text, revised_text, long_sentence_threshold=60):
    original = analyze_text(original_text, long_sentence_threshold)
    revised = analyze_text(revised_text, long_sentence_threshold)
    old_chars, new_chars = original["character_count"], revised["character_count"]
    delta = new_chars - old_chars
    return {
        "original": {k: original[k] for k in ("character_count", "sentence_count", "long_sentence_count", "duplicate_sentence_count")},
        "revised": {k: revised[k] for k in ("character_count", "sentence_count", "long_sentence_count", "duplicate_sentence_count")},
        "change": {
            "character_count_delta": delta,
            "character_count_change_percent": round(delta / old_chars * 100, 2) if old_chars else None,
            "long_sentence_count_delta": revised["long_sentence_count"] - original["long_sentence_count"],
            "duplicate_sentence_count_delta": revised["duplicate_sentence_count"] - original["duplicate_sentence_count"]
        },
        "note": "Structural metrics only; they do not measure factual accuracy, meaning preservation, or overall writing quality."
    }


if __name__ == "__main__":
    import argparse
    import json
    import sys

    parser = argparse.ArgumentParser(description="Analyze text or compare two versions.")
    parser.add_argument("--action", choices=["analyze", "compare"], default="analyze")
    parser.add_argument("--input-json", help="JSON input payload.")
    args = parser.parse_args()

    try:
        payload = json.loads(args.input_json) if args.input_json else json.load(sys.stdin)
        if not isinstance(payload, dict):
            raise ValueError("Input must be a JSON object.")
        if args.action == "analyze":
            result = {"status": "success", "data": analyze_text(
                payload.get("text"), payload.get("long_sentence_threshold", 60)
            ), "error": None}
        else:
            result = {"status": "success", "data": compare_texts(
                payload.get("original_text"), payload.get("revised_text"),
                payload.get("long_sentence_threshold", 60)
            ), "error": None}
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    except Exception as exc:
        print(json.dumps({
            "status": "error", "data": None,
            "error": {"type": type(exc).__name__, "message": str(exc)}
        }, ensure_ascii=False, indent=2, allow_nan=False))
        raise SystemExit(1)
