# Content Doctor Skill

## 目录
```text
content-doctor/
├── SKILL.md
├── references/
│   ├── writing_quality_guide.md
│   └── review_output_guide.md
├── tools/
│   ├── __init__.py
│   └── text_quality_tools.py
├── scripts/
│   ├── __init__.py
│   └── text_analyzer.py
├── examples/
│   └── test_prompt.md
└── tests/
    └── test_text_analyzer.py
```

## 分层说明
- `SKILL.md`：Agent 工作流程和调用规则。
- `references/`：Agent 读取的写作规范和输出标准。
- `tools/`：Agent-facing Python 工具接口。
- `scripts/`：底层统计与对比实现。

## 工具函数
```python
from tools.text_quality_tools import analyze_content, compare_versions
```

Agno 接入示意（按项目实际版本确认 Agent API）：
```python
from agno.agent import Agent
from tools.text_quality_tools import analyze_content, compare_versions

agent = Agent(tools=[analyze_content, compare_versions])
```

## 运行底层脚本
```bash
python scripts/text_analyzer.py --action analyze --input-json '{"text":"这是一段测试文本。"}'
```
工具接口和脚本均只依赖 Python 标准库。

## 测试
```bash
python -m unittest discover -s tests -v
```

脚本只统计文本结构，不自动判断事实准确性、语义质量或整体写作水平。
