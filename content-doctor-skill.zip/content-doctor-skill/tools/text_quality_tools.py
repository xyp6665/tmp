"""Agent-facing wrappers; register these plain callables as Agent tools."""
import sys
from pathlib import Path

_SKILL_ROOT = Path(__file__).resolve().parents[1]
_SCRIPTS_DIR = _SKILL_ROOT / "scripts"
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))

from text_analyzer import analyze_text, compare_texts

def analyze_content(text: str, long_sentence_threshold: int = 60) -> dict:
    """Analyze text structure, long sentences, repeated sentences and potential filler phrases."""
    try:
        return {"status": "success", "data": analyze_text(text, long_sentence_threshold), "error": None}
    except Exception as exc:
        return {"status": "error", "data": None, "error": {"type": type(exc).__name__, "message": str(exc)}}

def compare_versions(original_text: str, revised_text: str, long_sentence_threshold: int = 60) -> dict:
    """Compare objective text metrics before and after revision."""
    try:
        return {"status": "success", "data": compare_texts(original_text, revised_text, long_sentence_threshold), "error": None}
    except Exception as exc:
        return {"status": "error", "data": None, "error": {"type": type(exc).__name__, "message": str(exc)}}
