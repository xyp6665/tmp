"""Agent-facing tool wrappers."""
