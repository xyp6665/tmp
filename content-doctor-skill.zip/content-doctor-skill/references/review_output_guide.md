# Review Output Guide

## 默认报告结构
1. **总体诊断**：1–2 句话概括文本状态。
2. **主要问题**：2–5 项。每项说明表现，并标注依据是工具指标还是语言判断。
3. **优化方向**：说明本次改写优先处理什么。
4. **优化版本**：给出完整、可复制文本。
5. **前后对比**：展示字符数、句子数、超长句数、重复句数。说明这些指标不代表全部写作质量。
6. **需要确认**：列出事实、数据、指代或逻辑上的歧义。

## JSON 模式
用户明确要求 JSON 时，使用以下结构：
{
  "status": "success",
  "diagnosis": [],
  "revision_strategy": [],
  "revised_text": "",
  "metrics": {
    "original": {},
    "revised": {},
    "comparison": {}
  },
  "items_to_confirm": []
}
JSON 必须合法，不使用注释、尾随逗号或 Markdown 代码围栏。指标必须来自工具返回值。
