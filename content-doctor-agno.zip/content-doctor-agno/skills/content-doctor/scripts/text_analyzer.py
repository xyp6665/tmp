#!/usr/bin/env python3
"""Deterministic text metrics for Content Doctor. Python standard library only."""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from typing import Any

POTENTIAL_FILLER_PHRASES = [
    "在一定程度上", "值得注意的是", "非常", "比较",
    "相关", "进行", "然后", "其实",
]


def _validate_text(text: str) -> str:
    if not isinstance(text, str):
        raise ValueError("text must be a string.")
    if not text.strip():
        raise ValueError("text must not be empty.")
    return text.strip()


def _split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[。！？!?])\s*|\n+", text.strip())
    return [part.strip() for part in parts if part.strip()]


def analyze_text(text: str, long_sentence_threshold: int = 60) -> dict[str, Any]:
    """Calculate objective text-structure metrics."""
    text = _validate_text(text)
    if isinstance(long_sentence_threshold, bool) or not isinstance(long_sentence_threshold, int):
        raise ValueError("long_sentence_threshold must be an integer.")
    if long_sentence_threshold < 1:
        raise ValueError("long_sentence_threshold must be greater than zero.")

    compact = re.sub(r"\s", "", text)
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    sentences = _split_sentences(text)
    lengths = [len(re.sub(r"\s", "", sentence)) for sentence in sentences]

    normalized = [re.sub(r"\s+", "", sentence).lower() for sentence in sentences]
    sentence_counts = Counter(normalized)
    duplicate_sentences = [
        {"sentence": sentence, "count": count}
        for sentence, count in sentence_counts.items()
        if count > 1
    ]

    filler_phrases = [
        {"phrase": phrase, "count": text.count(phrase)}
        for phrase in POTENTIAL_FILLER_PHRASES
        if text.count(phrase) > 0
    ]

    return {
        "character_count": len(compact),
        "chinese_character_count": len(re.findall(r"[\u4e00-\u9fff]", text)),
        "english_word_count": len(re.findall(r"\b[A-Za-z]+(?:['’-][A-Za-z]+)?\b", text)),
        "paragraph_count": len(paragraphs),
        "sentence_count": len(sentences),
        "average_sentence_length": round(sum(lengths) / len(lengths), 2) if lengths else 0,
        "longest_sentence_length": max(lengths, default=0),
        "long_sentence_threshold": long_sentence_threshold,
        "long_sentence_count": sum(length > long_sentence_threshold for length in lengths),
        "duplicate_sentence_count": sum(count - 1 for count in sentence_counts.values() if count > 1),
        "duplicate_sentences": duplicate_sentences,
        "potential_filler_phrases": filler_phrases,
    }


def compare_texts(
    original_text: str,
    revised_text: str,
    long_sentence_threshold: int = 60,
) -> dict[str, Any]:
    """Compare objective structural metrics for two text versions."""
    original = analyze_text(original_text, long_sentence_threshold)
    revised = analyze_text(revised_text, long_sentence_threshold)
    original_chars = original["character_count"]
    revised_chars = revised["character_count"]
    delta = revised_chars - original_chars

    keys = (
        "character_count",
        "sentence_count",
        "long_sentence_count",
        "duplicate_sentence_count",
    )
    return {
        "original": {key: original[key] for key in keys},
        "revised": {key: revised[key] for key in keys},
        "change": {
            "character_count_delta": delta,
            "character_count_change_percent": round(delta / original_chars * 100, 2) if original_chars else None,
            "long_sentence_count_delta": revised["long_sentence_count"] - original["long_sentence_count"],
            "duplicate_sentence_count_delta": revised["duplicate_sentence_count"] - original["duplicate_sentence_count"],
        },
        "note": "Structural metrics only; they do not measure factual accuracy, meaning preservation, or overall writing quality.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyze text or compare two versions.")
    parser.add_argument("--action", choices=("analyze", "compare"), default="analyze")
    parser.add_argument("--input-json", help="JSON payload; otherwise read JSON from stdin.")
    args = parser.parse_args()

    try:
        payload = json.loads(args.input_json) if args.input_json else json.load(sys.stdin)
        if not isinstance(payload, dict):
            raise ValueError("Input must be a JSON object.")

        if args.action == "analyze":
            data = analyze_text(payload.get("text"), payload.get("long_sentence_threshold", 60))
        else:
            data = compare_texts(
                payload.get("original_text"),
                payload.get("revised_text"),
                payload.get("long_sentence_threshold", 60),
            )
        response = {"status": "success", "data": data, "error": None}
        print(json.dumps(response, ensure_ascii=False, indent=2, allow_nan=False))
        return 0
    except Exception as exc:
        response = {
            "status": "error",
            "data": None,
            "error": {"type": type(exc).__name__, "message": str(exc)},
        }
        print(json.dumps(response, ensure_ascii=False, indent=2, allow_nan=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
