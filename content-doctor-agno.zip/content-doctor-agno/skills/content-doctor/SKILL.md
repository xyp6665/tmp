---
name: content-doctor
description: Diagnose and improve Chinese or English marketing copy, business writing, reports, emails, and general prose. Use when the user asks to review, polish, rewrite, or compare a text for clarity, concision, repetition, sentence length, or tone.
compatibility: Requires Python 3.10+ and an Agno Agent that registers the Content Doctor tools.
allowed-tools:
  - analyze_content
  - compare_versions
metadata:
  version: "1.1.0"
  framework: "agno"
  category: "writing"
---

# Content Doctor

## Purpose

Follow a repeatable workflow: diagnose the supplied text, improve it according to the user's goal, re-check the revision, and compare objective text metrics.

Use this skill for marketing copy, brand descriptions, business emails, reports, academic paragraphs, and general prose.

Do not use it to verify external facts without sources, invent evidence, or fabricate citations.

## Agno skill access

This skill is loaded through Agno's `Skills` and `LocalSkills`.

When this skill is selected:
1. Call `get_skill_instructions("content-doctor")` to load these instructions.
2. Read `references/writing_quality_guide.md` using `get_skill_reference`.
3. Read `references/review_output_guide.md` using `get_skill_reference`.
4. Use the registered Agent tools `analyze_content` and `compare_versions` for objective analysis.

The skill name is not a callable function. Do not call `content-doctor(...)`.

## Workflow

1. **Understand the request**
   - Extract the full source text and the user's target audience, channel, tone, and goal.
   - If no text was provided, ask the user to paste it.
   - If the user only asks for diagnosis, do not rewrite unless requested.
   - If the user only asks for rewriting, keep the diagnosis concise.

2. **Load references**
   - Read `references/writing_quality_guide.md`.
   - Read `references/review_output_guide.md`.
   - Apply only principles relevant to the text type and user's stated goal.

3. **Analyze the original**
   - Call `analyze_content(text, long_sentence_threshold=60)`.
   - Use the returned metrics as the sole source for character counts, sentence counts, duplicate-sentence counts, and other computed metrics.
   - Distinguish deterministic metrics from qualitative language judgments.

4. **Diagnose**
   - Identify 2–5 high-impact issues.
   - Explain each issue with a concrete phrase or sentence from the source.
   - Do not treat a potential filler-phrase hit as an automatic error.

5. **Revise**
   - Preserve the author's intended meaning, stance, facts, numbers, names, dates, and qualifications.
   - Do not add unsupported claims, statistics, examples, citations, or personal experience.
   - Match the target format and tone.
   - If the source is ambiguous, preserve the ambiguity or flag it for confirmation rather than guessing.

6. **Re-analyze**
   - Call `analyze_content()` on the complete revised text.
   - Call `compare_versions(original_text, revised_text)`.

7. **Report**
   - Follow `references/review_output_guide.md`.
   - Explain that shorter text or improved structural metrics do not automatically prove better meaning, persuasiveness, or factual accuracy.

## Available Agent tools

The Agno Agent must register these Python callables from `tools/content_doctor_tools.py` inside this Skill directory:

- `analyze_content(text, long_sentence_threshold=60)`
- `compare_versions(original_text, revised_text, long_sentence_threshold=60)`

These are custom Agent tools. Agno `LocalSkills` does not auto-discover the `tools/` folder; the Agent bootstrap must import and register these callables explicitly.

For routine text analysis, use `analyze_content` and `compare_versions`. Do not invoke a second execution route for the same calculation.

## Script execution

The deterministic implementation is in `scripts/text_analyzer.py`.

In this project, the registered tools import and call the script implementation from the same Python environment. Agno also exposes `get_skill_script` as a native Skill access tool. Use it only when you specifically need to inspect or independently execute a script; set `execute=True` for execution. Reading a script with the default `execute=False` does not execute it.

## Error handling

- If a tool returns `status="error"`, report the failure accurately.
- Do not invent metrics or claim a script ran when it did not.
- If tool execution is unavailable, clearly label any advice as qualitative and not tool-verified.
- Never silently drop unclear text or numeric content.

## Default output

Unless the user requests another format, provide:

1. Overall diagnosis
2. Main issues (2–5 items)
3. Revision strategy
4. Complete revised text
5. Before/after metric comparison
6. Items the user should confirm

If the user explicitly requests JSON, return valid JSON only, without Markdown fences or surrounding prose.
