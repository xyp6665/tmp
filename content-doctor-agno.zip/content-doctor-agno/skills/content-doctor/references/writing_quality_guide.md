# Writing Quality Guide

This is a judgment framework, not a mechanical scorecard.

## Core principles

### Accuracy
- Preserve facts, numbers, dates, names, quotations, and qualifications.
- Do not turn uncertain statements into certain claims.
- Never invent data, sources, examples, or user experience.

### Clarity
- Keep each paragraph focused on a central idea.
- State the main point before supporting reasons or examples.
- Make references and pronouns unambiguous.

### Concision
- Merge repeated ideas.
- Split sentences that contain multiple unrelated central ideas.
- Replace vague wording with concrete verbs where appropriate.
- Do not remove necessary evidence, conditions, or limitations just to shorten the text.

### Coherence
- Check the logical relationship between sentences and paragraphs.
- Use cause, contrast, and progression markers only when the relationship is actually present.
- Avoid adding transition phrases mechanically.

### Tone and audience
- Academic: precise, cautious, clearly qualified.
- Business: direct, courteous, action-oriented.
- Marketing: customer-value-oriented, differentiated, and free of unsupported absolute promises.
- Social media: natural and distinctive without unnecessary formality.

## Review checklist

- Is the same point repeated?
- Are there overly long sentences with multiple main ideas?
- Are references ambiguous?
- Are abstract or empty phrases stacked together?
- Are there unnecessary clichés or transitions?
- Are absolute claims unsupported?
- Are all important facts and limitations preserved?
- Does the tone fit the audience and channel?

## Potential filler phrases

The script may flag expressions such as:
- 在一定程度上
- 值得注意的是
- 非常
- 比较
- 相关
- 进行
- 然后
- 其实

These expressions are not automatically wrong. Decide whether to keep, remove, or replace them based on context.

## Non-negotiable constraints

- Do not change the user's position.
- Do not add facts that were not supplied.
- Do not turn correlation into causation.
- Do not treat phrase-hit counts as a writing-quality score.
