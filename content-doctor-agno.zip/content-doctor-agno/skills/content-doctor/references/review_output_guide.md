# Review Output Guide

## Default report structure

1. **Overall diagnosis** — summarize the text's main strengths and weaknesses in 1–2 sentences.
2. **Main issues** — list 2–5 issues, each with a concrete example and its basis (tool metric or qualitative judgment).
3. **Revision strategy** — state what the revision prioritizes.
4. **Revised version** — provide the complete copy-ready text.
5. **Before/after comparison** — show character count, sentence count, long-sentence count, and duplicate-sentence count where available.
6. **Items to confirm** — identify factual, numerical, referential, or logical ambiguities.

## JSON mode

When the user explicitly requests JSON, return this structure:

{
  "status": "success",
  "diagnosis": [],
  "revision_strategy": [],
  "revised_text": "",
  "metrics": {
    "original": {},
    "revised": {},
    "comparison": {}
  },
  "items_to_confirm": []
}

JSON must be valid. Do not include comments, trailing commas, or Markdown fences. All numeric metrics must come from tool results.
