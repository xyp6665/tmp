"""Custom Agent tools explicitly registered with Agno; not auto-discovered by LocalSkills."""
