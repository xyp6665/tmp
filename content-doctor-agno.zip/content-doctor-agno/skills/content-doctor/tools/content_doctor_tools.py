"""Agent-facing Agno tools that delegate to the Skill's script implementation."""
from __future__ import annotations

import importlib.util
from pathlib import Path
from typing import Any

_SKILL_DIR = Path(__file__).resolve().parents[1]
_SCRIPT_PATH = _SKILL_DIR / "scripts" / "text_analyzer.py"

_spec = importlib.util.spec_from_file_location("content_doctor_text_analyzer", _SCRIPT_PATH)
if _spec is None or _spec.loader is None:
    raise ImportError(f"Cannot load Content Doctor script: {_SCRIPT_PATH}")
_analyzer = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_analyzer)


def analyze_content(text: str, long_sentence_threshold: int = 60) -> dict[str, Any]:
    """Analyze a text's length, paragraphs, sentences, long sentences, duplicates and possible filler phrases."""
    try:
        return {
            "status": "success",
            "data": _analyzer.analyze_text(text, long_sentence_threshold),
            "error": None,
        }
    except Exception as exc:
        return {
            "status": "error",
            "data": None,
            "error": {"type": type(exc).__name__, "message": str(exc)},
        }


def compare_versions(
    original_text: str,
    revised_text: str,
    long_sentence_threshold: int = 60,
) -> dict[str, Any]:
    """Compare objective text metrics before and after revision."""
    try:
        return {
            "status": "success",
            "data": _analyzer.compare_texts(original_text, revised_text, long_sentence_threshold),
            "error": None,
        }
    except Exception as exc:
        return {
            "status": "error",
            "data": None,
            "error": {"type": type(exc).__name__, "message": str(exc)},
        }
