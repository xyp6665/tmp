# Content Doctor — Agno Adapted Skill

This project adapts Content Doctor to Agno's native Skills API.

## Directory structure

```text
content-doctor-agno/
├── app.py
├── requirements.txt
├── skills/
│   └── content-doctor/
│       ├── SKILL.md
│       ├── references/
│       │   ├── writing_quality_guide.md
│       │   └── review_output_guide.md
│       ├── scripts/
│       │   └── text_analyzer.py
│       └── tools/
│           ├── __init__.py
│           └── content_doctor_tools.py
├── examples/
│   └── test_prompt.md
└── tests/
    └── test_content_doctor.py
```

## Important: Agno-native folders vs custom extension

Agno's documented `LocalSkills` convention recognizes a Skill directory containing:
- `SKILL.md`
- optional `scripts/`
- optional `references/`

Agno does **not** automatically discover a `tools/` folder inside a Skill. This example keeps `tools/` inside the Skill package for convenient Docker transfer, but the Agent bootstrap explicitly imports and registers those functions with `Agent(tools=[...])`.

This preserves the four-way separation:
- `SKILL.md`: workflow and instructions.
- `references/`: on-demand guidance documents.
- `scripts/`: deterministic implementation.
- `tools/`: custom Agent-callable wrappers, explicitly registered by the application.

## Agno native Skill tools

After loading `Skills(loaders=[LocalSkills("skills")])`, Agno provides:
- `get_skill_instructions(skill_name)`
- `get_skill_reference(skill_name, reference_path)`
- `get_skill_script(skill_name, script_path, execute=False, args=None, timeout=30)`

The model should call `get_skill_instructions("content-doctor")`, then load the relevant references with `get_skill_reference`.

`get_skill_script` reads a script by default. It executes a script only when `execute=True`. The script is executed in the environment where the Agno Agent process runs.

## Custom tools

The custom tools are in `skills/content-doctor/tools/content_doctor_tools.py`:
```python
analyze_content(text, long_sentence_threshold=60)
compare_versions(original_text, revised_text, long_sentence_threshold=60)
```

They are registered explicitly in `app.py`:
```python
agent = Agent(
    skills=skills,
    tools=[analyze_content, compare_versions],
)
```

The wrappers call functions implemented in `scripts/text_analyzer.py`. The tool wrappers provide typed interfaces and structured success/error results.

## Run

Python 3.10+ recommended.

```bash
python -m pip install -r requirements.txt

export MODEL_ID="your-model-id"
export MODEL_BASE_URL="https://your-openai-compatible-endpoint/v1"
export MODEL_API_KEY="your-api-key"

python app.py
```

This example uses Agno's `OpenAILike` adapter for OpenAI-compatible endpoints. If your provider is not OpenAI-compatible, replace the model adapter in `app.py` with the matching Agno model class.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Run the script directly

```bash
python skills/content-doctor/scripts/text_analyzer.py \
  --action analyze \
  --input-json '{"text":"这是一段需要分析的文本。"}'
```

Compare two versions:
```bash
python skills/content-doctor/scripts/text_analyzer.py \
  --action compare \
  --input-json '{"original_text":"原文。","revised_text":"修改稿。"}'
```

## Docker execution boundary

For your Brain → Docker Skill Executor architecture, copy the complete `skills/content-doctor/` directory into the Docker execution environment, and run the Agno Agent there. The native Skill access tools and the custom registered tools then execute in the Docker environment of that Agent process.

If only the Skill folder is copied, the Skill's `tools/`, `scripts/`, and `references/` are all included. The app bootstrap still needs to import `tools/content_doctor_tools.py` from the copied folder and register its functions.

Do not assume that Agno itself creates a Docker sandbox. Container isolation, file permissions, network access, process limits, and timeouts must be configured by your execution platform.

## References

- Agno Skills overview: https://docs.agno.com/skills/overview
- Loading Skills: https://docs.agno.com/skills/loading-skills
- Creating Skills: https://docs.agno.com/skills/creating-skills
- OpenAI-compatible models: https://docs.agno.com/models/providers/openai-like
