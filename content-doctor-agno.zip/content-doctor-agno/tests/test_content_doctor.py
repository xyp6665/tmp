import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILL_DIR = ROOT / "skills" / "content-doctor"
sys.path.insert(0, str(SKILL_DIR / "tools"))

from content_doctor_tools import analyze_content, compare_versions


class ContentDoctorAgnoToolTests(unittest.TestCase):
    def test_analyze_tool(self):
        result = analyze_content("第一句。第二句。")
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["data"]["sentence_count"], 2)

    def test_duplicate_detection(self):
        result = analyze_content("同一句话。另一句。同一句话。")
        self.assertEqual(result["data"]["duplicate_sentence_count"], 1)

    def test_long_sentence_detection(self):
        result = analyze_content("这是一条很长的句子" * 8, long_sentence_threshold=20)
        self.assertGreater(result["data"]["long_sentence_count"], 0)

    def test_compare_tool(self):
        result = compare_versions("这是一段较长的原始文本。", "修改稿。")
        self.assertEqual(result["status"], "success")
        self.assertLess(result["data"]["change"]["character_count_delta"], 0)

    def test_invalid_input(self):
        result = analyze_content("   ")
        self.assertEqual(result["status"], "error")


if __name__ == "__main__":
    unittest.main(verbosity=2)
