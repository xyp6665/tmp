"""Minimal Agno runner for the Content Doctor Skill.

This example uses Agno's OpenAI-compatible adapter. Configure MODEL_ID,
MODEL_BASE_URL, and MODEL_API_KEY for your own model endpoint.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from agno.agent import Agent
from agno.models.openai.like import OpenAILike
from agno.skills import LocalSkills, Skills

PROJECT_ROOT = Path(__file__).resolve().parent
SKILLS_DIR = PROJECT_ROOT / "skills"
SKILL_DIR = SKILLS_DIR / "content-doctor"

# Agno's LocalSkills discovers SKILL.md, references/, and scripts/.
skills = Skills(loaders=[LocalSkills(str(SKILLS_DIR))])

# The tools/ directory is a project-specific extension, not an Agno LocalSkills
# convention. Register its Python callables explicitly on the Agent.
TOOLS_DIR = SKILL_DIR / "tools"
sys.path.insert(0, str(TOOLS_DIR))
from content_doctor_tools import analyze_content, compare_versions  # noqa: E402

if "content-doctor" not in skills.get_skill_names():
    raise RuntimeError(
        f"content-doctor did not load. Loaded skills: {skills.get_skill_names()}"
    )

required_env = ("MODEL_ID", "MODEL_BASE_URL", "MODEL_API_KEY")
missing = [key for key in required_env if not os.getenv(key)]
if missing:
    raise RuntimeError(
        "Set these environment variables before running: " + ", ".join(missing)
    )

model = OpenAILike(
    id=os.environ["MODEL_ID"],
    base_url=os.environ["MODEL_BASE_URL"],
    api_key=os.environ["MODEL_API_KEY"],
)

agent = Agent(
    name="Content Doctor Agent",
    model=model,
    skills=skills,
    tools=[analyze_content, compare_versions],
    instructions=[
        "You are a writing review and revision agent.",
        "When a request matches a loaded skill, call get_skill_instructions(skill_name) first.",
        "For Content Doctor, read both references using get_skill_reference.",
        "Use analyze_content and compare_versions for objective metrics; never invent tool results.",
        "Do not call a skill name as if it were a function.",
    ],
    markdown=True,
    debug_mode=True,
)

if __name__ == "__main__":
    prompt_path = PROJECT_ROOT / "examples" / "test_prompt.md"
    prompt = prompt_path.read_text(encoding="utf-8")
    agent.print_response(prompt, stream=True)
